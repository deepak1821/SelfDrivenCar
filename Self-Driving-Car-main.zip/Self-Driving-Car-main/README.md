# Self-Driving-Car

A simulation of a self driven car. The UI and graphics was designed using Pygame. The car learns on how to move around using the technique of reinforcement learning. The image capturing sensing model is trained using CNN. 
